
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Oleg.Chumakov
 */
public class QuickUnionUF1 {

  public static int rank(int key, int[] a) {
    int lo = 0;
    int hi = a.length - 1;

    String s = "";
    while (lo <= hi) {
      // Key is in a[lo..hi] or not present.
      int mid = lo + (hi - lo) / 2;
      s += a[mid] + " ";
      if (key < a[mid]) {
        hi = mid - 1;
      } else {
//        s += a[mid] + " ";
        if (key > a[mid]) {
          lo = mid + 1;
        } else {
          return mid;
        }
      }
    }
    System.out.println(s);
    return -1;
  }

  private static double lg(double v) {
    return Math.log(v) / Math.log(2);
  }

  private static double lg(double v, double base) {
    return Math.log(v) / Math.log(base);
  }

  // use natural order and Comparable interface
  public static void sortInsertion(Comparable[] a) {
    int N = a.length;
    int cntr = 0;
    for (int i = 0; i < N; i++) {
      for (int j = i; j > 0 && less(a[j], a[j - 1]); j--) {
        exch(a, j, j - 1);
        printMatch(a);
        cntr++;
//        printArray(a, cntr + " : ");
      }
//      assert isSorted(a, 0, i);
    }
//    assert isSorted(a);
  }

  public static void shellSort(Comparable[] a) {
    int N = a.length;

    // 3x+1 increment sequence:  1, 4, 13, 40, 121, 364, 1093, ... 
    int h = 1;
    while (h < N / 3) {
      h = 3 * h + 1;
    }

    while (h >= 1) {
      // h-sort the array
      for (int i = h; i < N; i++) {
        for (int j = i; j >= h && less(a[j], a[j - h]); j -= h) {
          exch(a, j, j - h);
          printMatch(a);
        }
      }
//            assert isHsorted(a, h); 
      h /= 3;
    }
//        assert isSorted(a);
  }

  private static void printArray(Object[] a, String s) {
    String r = s;
    for (int i = 0; i < a.length; i++) {
      if (a[i] == null) {
        r += "null ";
      } else {
        r += a[i].toString() + " ";
      }
    }
    System.out.println(r);
  }

  public static void selectionSort(Comparable[] a) {
    int N = a.length;
    for (int i = 0; i < N; i++) {
      int min = i;
      for (int j = i + 1; j < N; j++) {
        if (less(a[j], a[min])) {
          min = j;
        }
      }
      exch(a, i, min);

      printMatch(a);
//            assert isSorted(a, 0, i);
    }
//        assert isSorted(a);
  }

  /**
   * *********************************************************************
   * Helper sorting functions
   * *********************************************************************
   */
  // is v < w ?
  private static boolean less(Comparable v, Comparable w) {
    return (v.compareTo(w) < 0);
  }

  // is v < w ?
  private static boolean less(Comparator c, Object v, Object w) {
    return (c.compare(v, w) < 0);
  }

  // exchange a[i] and a[j]
  private static void exch(Object[] a, int i, int j) {
    Object swap = a[i];
    a[i] = a[j];
    a[j] = swap;
  }

  // exchange a[i] and a[j]  (for indirect sort)
  private static void exch(int[] a, int i, int j) {
    int swap = a[i];
    a[i] = a[j];
    a[j] = swap;
  }
  // stably merge a[lo .. mid] with a[mid+1 .. hi] using aux[lo .. hi]
  static int cntr = 0;

  public static void merge(Comparable[] a, Comparable[] aux, int lo, int mid, int hi) {

    // precondition: a[lo .. mid] and a[mid+1 .. hi] are sorted subarrays
//        assert isSorted(a, lo, mid);
//        assert isSorted(a, mid+1, hi);

    // copy to aux[]
    for (int k = lo; k <= hi; k++) {
      aux[k] = a[k];
    }

    // merge back to a[]
    int i = lo, j = mid + 1;
    for (int k = lo; k <= hi; k++) {
      if (i > mid) {
        a[k] = aux[j++];
      } else if (j > hi) {
        a[k] = aux[i++];
      } else if (less(aux[j], aux[i])) {
        a[k] = aux[j++];
      } else {
        a[k] = aux[i++];
      }

      printMatch(a);
    }
//    cntr++;
//    printArray(a, cntr + " : ");
    // postcondition: a[lo .. hi] is sorted
//        assert isSorted(a, lo, hi);
  }

  // mergesort a[lo..hi] using auxiliary array aux[lo..hi]
  private static void mergeSort(Comparable[] a, Comparable[] aux, int lo, int hi) {
    if (hi <= lo) {
      return;
    }
    int mid = lo + (hi - lo) / 2;
    mergeSort(a, aux, lo, mid);
    mergeSort(a, aux, mid + 1, hi);
    merge(a, aux, lo, mid, hi);
  }

  public static void mergeSort(Comparable[] a) {
    Comparable[] aux = new Comparable[a.length];
    mergeSort(a, aux, 0, a.length - 1);
//        assert isSorted(a);
  }
  // partition the subarray a[lo .. hi] by returning an index j
  // so that a[lo .. j-1] <= a[j] <= a[j+1 .. hi]

  // stably merge a[lo..m] with a[m+1..hi] using aux[lo..hi]
  private static void mergeBU(Comparable[] a, Comparable[] aux, int lo, int m, int hi) {

    // copy to aux[]
    for (int k = lo; k <= hi; k++) {
      aux[k] = a[k];
    }

    // merge back to a[]
    int i = lo, j = m + 1;
    for (int k = lo; k <= hi; k++) {
      if (i > m) {
        a[k] = aux[j++];
      } else if (j > hi) {
        a[k] = aux[i++];
      } else if (less(aux[j], aux[i])) {
        a[k] = aux[j++];
      } else {
        a[k] = aux[i++];
      }

      printMatch(a);
    }

  }

  // bottom-up mergesort
  public static void mergeBUsort(Comparable[] a) {
    int N = a.length;
    Comparable[] aux = new Comparable[N];
    for (int n = 1; n < N; n = n + n) {
      for (int i = 0; i < N - n; i += n + n) {
        int lo = i;
        int m = i + n - 1;
        int hi = Math.min(i + n + n - 1, N - 1);
        mergeBU(a, aux, lo, m, hi);
      }
    }
//        assert isSorted(a);
  }

  // quicksort the array
  public static void qsort(Comparable[] a) {
//    StdRandom.shuffle(a);
    qsort(a, 0, a.length - 1);
  }

  // quicksort the subarray from a[lo] to a[hi]
  private static void qsort(Comparable[] a, int lo, int hi) {
    if (hi <= lo) {
      return;
    }
    int j = partition(a, lo, hi);
    qsort(a, lo, j - 1);
    qsort(a, j + 1, hi);
//        assert isSorted(a, lo, hi);
  }

  // partition the subarray a[lo .. hi] by returning an index j
  // so that a[lo .. j-1] <= a[j] <= a[j+1 .. hi]
  private static int partition(Comparable[] a, int lo, int hi) {
    int i = lo;
    int j = hi + 1;
    Comparable v = a[lo];
    while (true) {

      // find item on lo to swap
      while (less(a[++i], v)) {
        if (i == hi) {
          break;
        }
      }

      // find item on hi to swap
      while (less(v, a[--j])) {
        if (j == lo) {
          break;      // redundant since a[lo] acts as sentinel
        }
      }
      // check if pointers cross
      if (i >= j) {
        break;
      }

      exch(a, i, j);
      printMatch(a);
    }

    // put v = a[j] into position
    exch(a, lo, j);
    printMatch(a);
    // with a[lo .. j-1] <= a[j] <= a[j+1 .. hi]
    return j;
  }

  // quicksort the array a[] using 3-way partitioning
  public static void q3sort(Comparable[] a) {
    q3sort(a, 0, a.length - 1);
//    assert isSorted(a);
  }

  // quicksort the subarray a[lo .. hi] using 3-way partitioning
  private static void q3sort(Comparable[] a, int lo, int hi) {
    if (hi <= lo) {
      return;
    }
    int lt = lo, gt = hi;
    Comparable v = a[lo];
    int i = lo;
    while (i <= gt) {
      int cmp = a[i].compareTo(v);
      if (cmp < 0) {
        exch(a, lt++, i++);
      } else if (cmp > 0) {
        exch(a, i, gt--);
      } else {
        i++;
      }
      printMatch(a);
    }

    // a[lo..lt-1] < v = a[lt..gt] < a[gt+1..hi]. 
    q3sort(a, lo, lt - 1);
    q3sort(a, gt + 1, hi);
//    assert isSorted(a, lo, hi);
  }

  public static void hsort(Comparable[] pq) {
    int N = pq.length;
    for (int k = N / 2; k >= 1; k--) {
      sink(pq, k, N);
    }
    while (N > 1) {
      hexch(pq, 1, N--);
      printMatch(pq);
      sink(pq, 1, N);
    }
  }

  /**
   * *********************************************************************
   * Helper functions to restore the heap invariant.
   * ********************************************************************
   */
  private static void sink(Comparable[] pq, int k, int N) {
    while (2 * k <= N) {
      int j = 2 * k;
      if (j < N && less(pq, j, j + 1)) {
        j++;
      }
      if (!less(pq, k, j)) {
        break;
      }
      hexch(pq, k, j);
      printMatch(pq);
      k = j;
    }
  }

  private static void hexch(Object[] pq, int i, int j) {
    Object swap = pq[i - 1];
    pq[i - 1] = pq[j - 1];
    pq[j - 1] = swap;
  }

  private static boolean less(Comparable[] pq, int i, int j) {
    return pq[i - 1].compareTo(pq[j - 1]) < 0;
  }

  private static void kshuffle(String[] a) {
    int N = a.length;
    // shuffle
    for (int i = 0; i < N; i++) {
      // int from remainder of deck
      int r = i + (int) (Math.random() * (N - i));
      String swap = a[r];
      a[r] = a[i];
      printMatch(a);
      a[i] = swap;
      printMatch(a);
    }
  }

  private static boolean equals(Object[] a, Object[] b) {
    if (a.length != b.length) {
      return false;
    }

    for (int i = 0; i < a.length; i++) {
      if (!a[i].equals(b[i])) {
        return false;
      }
    }
    return true;
  }
  static String[][] results = new String[12][24];

  private static void printMatch(Object[] a) {
    printArray(a, " -- ");
    for (int i = 0; i < 12; i++) {
      if (equals(a, results[i])) {
//        printArray(results[i], " == ");
        System.out.println("founded on: " + (i));
      }
    }
  }

  public static void main(String[] args) {
//    MaxPQ1<Integer> bh = new MaxPQ1<Integer>();
////     91 72 65 71 51 12 22 52 57 33 
//    bh.insert(91);
//    bh.insert(72);
//    bh.insert(65);
//    bh.insert(71);
//    bh.insert(51);
//    bh.insert(12);
//    bh.insert(22);
//    bh.insert(52);
//    bh.insert(57);
//    bh.insert(33);
//    
//    bh.delMax();
//    bh.delMax();
//    bh.delMax();
//    printArray(bh.pq, "");

    In in = new In(args[0]);
    int it = 0;
    int jt = 0;

    while (!in.isEmpty()) {
      results[jt][it] = in.readString();
      jt++;
      if (jt > 11) {
        it++;
        jt = 0;
      }
    }
    String[] original = results[1];
    String[] sorted = results[11];
//Shuffle
    String[] test = new String[original.length];
    System.arraycopy(original, 0, test, 0, original.length);
    //    Arrays.sort(test);
//    hsort(test);
//    kshuffle(test);
//    printMatch(test);
//Heap
    // 0   1 2 3 4 5 6 7 8 9 10 11
    // I   0 1 8 6 3 4 9 7 5  9 10


//    BST<Integer, Integer> bst = new BST<Integer, Integer>();
//    BST<String, Integer> bst = new BST<String, Integer>();
//    83 61 78 22 21 84 96 50 75 57 
//     J M O C P S R W Q F 
//    bst.put(83, 0);
//    bst.put(61, 0);
//    bst.put(78, 0);
//    bst.put(22, 0);
//    bst.put(21, 0);
//    bst.put(84, 0);
//    bst.put(96, 0);
//    bst.put(50, 0);
//    bst.put(75, 0);
//    bst.put(57, 0);
//    String res = "";
//    for (Integer k : bst.levelOrder()) {
//      res += k + " ";
//    }
//    System.out.println(res);

//
//    RB<Integer, Integer> rb = new RB<Integer, Integer>();
//    String inp = "38 31 97 10 34 86 99 61 96 39 88 35 80 ";
//    String[] fields = inp.trim().split("\\s+");
//    for (int i = 0; i < fields.length; i++) {
//      rb.put(Integer.parseInt(fields[i]), jt);
//    }
//
//    String out = "";
//    for (Integer k : rb.levelOrder()) {
//      out += k + " ";
//    }
//    System.out.println(out);
//    rb.printRed();


    KdTree kd = new KdTree();
    kd.insert(new Point2D(0.91, 0.79));
    kd.insert(new Point2D(0.21, 0.29));
    kd.insert(new Point2D(0.85, 0.56));
    kd.insert(new Point2D(0.09, 0.46));
    kd.insert(new Point2D(0.19, 0.44));
    kd.insert(new Point2D(0.01, 0.68));
    kd.insert(new Point2D(0.90, 0.04));
    kd.insert(new Point2D(0.84, 0.61));
//A B G C D E F H
    String out = "";
    for (Point2D p : kd.levelOrder()) {
      out += p.toString() + " ";
    }
    System.out.println(out);
    //    for (int i = 0; i < 12; i++) {
    //      if (equals(original, results[i])) {
    //        System.out.println("founded on: " + (i - 1));
    //      }
    //    }
    //    System.out.println(equals(sorted));
    //    for (int i = 0; i < 12; i++) {
    //      printArray(results[i], "");
    //    }
    //    System.out.println(equals(results[1], a));
    //    int[][] blocks = new int[N][N];
    //    for (int i = 0; i < N; i++) {
    //      for (int j = 0; j < N; j++) {
    //        blocks[i][j] = in.readInt();
    //      }
    //    }
    //    String[] a = new String[]{
    //      "leaf", "rose", "sand", "wine", "blue", "bone", "herb", "kobi", "mist",
    //      "navy", "ceil", "corn", "iris", "bole", "mint", "dust", "buff", "puce",
    //      "silk", "teal", "gold", "dusk", "onyx", "lust"
    //    };71 39 50 30 12 57 77 42 79 52 72 17 
    //    Integer[] whitelist = new Integer[]{71, 39, 50, 30, 12, 57, 77, 42, 79, 52, 72, 17};
    //    mergeSort(whitelist);
    //    Selection.sort(a);
    //    //    Arrays.sort(a);
    //    printArray(a, "");
    //    int[] whitelist = new int[]{16,
    //      24, 25, 32, 33, 35, 41, 55, 59, 63, 71, 73, 79, 82, 90};
    //        Arrays.sort(whitelist);
    //    System.out.println(rank(93, whitelist));
    //        // read key; print if not in whitelist
    //        while (!StdIn.isEmpty()) {
    //            int key = StdIn.readInt();
    //            if (rank(key, whitelist) == -1)
    //                StdOut.println(key);
    //        }
    //    double result = (lg(2286.26)-lg(0.19))/(lg(46656)-lg(1296));
    //    System.out.println(result);
    //            Integer[] a = new Integer[]{30, 68, 34, 48, 44, 65, 31, 83, 26, 47, 22, 84};
    //    partition(a, 0, a.length - 1);
    //    int N = 100000;
    //
    //    int cntr = 0;
    //    int sum = 0;
    //    for (int i = 1; i <= 4 * N; i = i * 4) {
    //      cntr++;
    //      for (int j = 0; j < i; j++) {
    //        sum++;
    //      }
    //    }
    //    System.out.println(N * lg(N, 2));
    //    System.out.println(sum);
  }
//
//  public static void main(final String[] args) {
//    QuickUnionUF1 q = new QuickUnionUF1(10);
////       3-6 3-8 7-1 0-2 7-2 4-5 8-9 9-4 8-2 
//    q.union(3, 6);
//    q.union(3, 8);
//    q.union(7, 1);
//    q.union(0, 2);
//    q.union(7, 2);
//    q.union(4, 5);
// q.union(8, 9);
//  q.union(9, 4);
//    q.union(8, 2);
//    String s = "";
//    String ind = "";
//    for (int i = 0; i < q.id.length; i++) {
//      s += q.id[i] + " ";
//    }
//    System.out.println(s);
//    
//    BinarySearch
////    0 1 2 3 4 5 6 7 8 9
////    5 1 4 9 5 1 9 8 5 5
//  }
}
